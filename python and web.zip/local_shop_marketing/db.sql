/*
SQLyog Community v13.1.5  (64 bit)
MySQL - 5.6.12-log : Database - newproject
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`newproject` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `newproject`;

/*Table structure for table `assign` */

DROP TABLE IF EXISTS `assign`;

CREATE TABLE `assign` (
  `assign_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT NULL,
  `boy_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`assign_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

/*Data for the table `assign` */

insert  into `assign`(`assign_id`,`order_id`,`boy_id`,`date`,`status`) values 
(1,2,6,'2023-03-05','assigned'),
(2,9,10,'2023-03-05','Delivered'),
(3,14,10,'2023-03-05','Delivered'),
(4,20,10,'2023-03-05','assigned'),
(5,21,9,'2023-03-05','I am coming '),
(6,18,9,'2023-03-05','assigned'),
(7,22,9,'2023-03-05','assigned');

/*Table structure for table `cart` */

DROP TABLE IF EXISTS `cart`;

CREATE TABLE `cart` (
  `cart_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `amount` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`cart_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `cart` */

/*Table structure for table `category` */

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `category` */

insert  into `category`(`category_id`,`category`) values 
(1,'Dry fruit'),
(2,'Grocery'),
(4,'Stationary');

/*Table structure for table `complaints` */

DROP TABLE IF EXISTS `complaints`;

CREATE TABLE `complaints` (
  `c_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `complaint` text,
  `date` varchar(50) DEFAULT NULL,
  `time` varchar(50) DEFAULT NULL,
  `reply` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`c_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `complaints` */

insert  into `complaints`(`c_id`,`user_id`,`complaint`,`date`,`time`,`reply`) values 
(1,8,'This is a complaint ','2023-03-05','07:33:27','This is a reply\r\n'),
(2,8,'This is another complaint ','2023-03-05','07:33:48','pending'),
(3,8,'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.','2023-03-05','17:02:16','pending');

/*Table structure for table `delivery_boy` */

DROP TABLE IF EXISTS `delivery_boy`;

CREATE TABLE `delivery_boy` (
  `boy_id` int(11) NOT NULL AUTO_INCREMENT,
  `login_id` int(11) DEFAULT NULL,
  `sh_id` int(11) DEFAULT NULL,
  `vehicle name` varchar(30) DEFAULT NULL,
  `boy_name` varchar(30) DEFAULT NULL,
  `phone` varchar(10) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`boy_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `delivery_boy` */

insert  into `delivery_boy`(`boy_id`,`login_id`,`sh_id`,`vehicle name`,`boy_name`,`phone`,`email`) values 
(3,9,2,'honda','aby','8888888888','aby@gmail.com'),
(4,10,3,'activa','jack','7766557788','jack@gmail.com');

/*Table structure for table `location` */

DROP TABLE IF EXISTS `location`;

CREATE TABLE `location` (
  `location_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `latitude` varchar(20) DEFAULT NULL,
  `longitude` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `location` */

insert  into `location`(`location_id`,`user_id`,`latitude`,`longitude`) values 
(1,8,'11.25773996','75.78459486'),
(2,7,'11.25767541','75.78453745'),
(3,10,'11.25774346','75.78458931'),
(4,12,'11.2576909','75.784549'),
(5,13,'11.25773915','75.78458253'),
(6,9,'11.25777821','75.78457833');

/*Table structure for table `login` */

DROP TABLE IF EXISTS `login`;

CREATE TABLE `login` (
  `login_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`login_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

/*Data for the table `login` */

insert  into `login`(`login_id`,`username`,`password`,`type`) values 
(1,'admin','admin','admin'),
(2,'aman','aman','shop'),
(3,'Babu','babu','shop'),
(4,'david','david','shop'),
(5,'sasi','123','rejected'),
(8,'anuvind','1234','user'),
(9,'aby','aby','delivery_agent'),
(10,'jack','jack','delivery_agent'),
(12,'arun','arun','user'),
(13,'Akshay','Akshay','user');

/*Table structure for table `offer` */

DROP TABLE IF EXISTS `offer`;

CREATE TABLE `offer` (
  `p_id` int(11) DEFAULT NULL,
  `offer` varchar(30) DEFAULT NULL,
  `offer_details` varchar(50) DEFAULT NULL,
  `from_date` varchar(50) DEFAULT NULL,
  `offer_id` int(11) NOT NULL AUTO_INCREMENT,
  `to_date` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`offer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `offer` */

insert  into `offer`(`p_id`,`offer`,`offer_details`,`from_date`,`offer_id`,`to_date`) values 
(1,'50','50% off for 10 days!','2023-03-04',1,'2023-03-14'),
(7,'10','10% off for 5 days!!','2023-03-04',2,'2023-03-09');

/*Table structure for table `order` */

DROP TABLE IF EXISTS `order`;

CREATE TABLE `order` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `amount` bigint(20) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

/*Data for the table `order` */

insert  into `order`(`order_id`,`user_id`,`amount`,`status`,`date`) values 
(1,8,300,'pending','2023-03-05'),
(2,8,565,'ordered',NULL),
(3,8,600,'pending',NULL),
(4,8,300,'pending','2023-03-05'),
(5,8,705,'pending',NULL),
(6,8,10,'pending','2023-03-05'),
(7,8,45,'pending','2023-03-05'),
(8,8,145,'pending',NULL),
(9,8,150,'ordered','2023-03-05'),
(10,8,0,'pending',NULL),
(11,8,42,'pending',NULL),
(12,8,0,'pending','2023-03-05'),
(13,8,0,'pending','2023-03-05'),
(14,8,1110,'Delivered','2023-03-05'),
(15,8,0,'pending','2023-03-05'),
(16,8,0,'pending','2023-03-05'),
(17,8,178,'pending','2023-03-05'),
(18,8,0,'ordered','2023-03-05'),
(19,8,5,'cart','2023-03-05'),
(20,12,75,'ordered','2023-03-05'),
(21,13,270,'ordered','2023-03-05'),
(22,13,90,'ordered','2023-03-05');

/*Table structure for table `order_item` */

DROP TABLE IF EXISTS `order_item`;

CREATE TABLE `order_item` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `offer` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;

/*Data for the table `order_item` */

insert  into `order_item`(`item_id`,`order_id`,`pid`,`quantity`,`status`,`offer`) values 
(1,1,4,2,'pending','0'),
(2,2,7,3,'pending','90'),
(3,2,7,3,'pending','90'),
(4,2,9,1,'pending','25'),
(5,3,5,4,'pending','75'),
(6,3,5,4,'pending','75'),
(7,4,4,2,'pending','0'),
(8,5,7,1,'pending','90'),
(9,5,7,1,'pending','90'),
(10,6,2,2,'pending','0'),
(11,5,9,3,'pending','25'),
(12,5,4,3,'pending','150'),
(13,7,1,1,'pending','0'),
(14,8,1,3,'pending','22.5'),
(15,8,1,3,'pending','22.5'),
(16,8,3,2,'pending','5'),
(17,9,5,2,'pending','0'),
(18,10,9,10,'pending','25'),
(19,11,10,3,'pending','7'),
(20,11,10,3,'pending','7'),
(21,12,8,4,'pending','20'),
(22,13,9,2,'pending','25'),
(23,14,7,9,'pending','90'),
(24,14,4,2,'pending','150'),
(25,15,1,1,'pending','22.5'),
(26,16,1,2,'pending','22.5'),
(27,17,1,7,'pending','22.5'),
(28,17,2,4,'pending','5'),
(29,18,3,4,'pending','5'),
(30,19,2,4,'pending','5'),
(31,20,5,10,'pending','75'),
(32,21,1,6,'pending','0'),
(33,22,1,2,'pending','0');

/*Table structure for table `product` */

DROP TABLE IF EXISTS `product`;

CREATE TABLE `product` (
  `p_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` int(11) DEFAULT NULL,
  `p_name` varchar(20) DEFAULT NULL,
  `shop_id` int(11) DEFAULT NULL,
  `c_id` int(11) DEFAULT NULL,
  `image` text,
  `details` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`p_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

/*Data for the table `product` */

insert  into `product`(`p_id`,`price`,`p_name`,`shop_id`,`c_id`,`image`,`details`) values 
(1,45,'Classmate notebook',2,4,'Classmate-Notebook-Ruled-Single-Line-172-Pages-Pack-of-3-4.jpg','notebook'),
(2,5,'Apsara pencil',2,4,'apsara.jpg','pencil'),
(3,5,'Lexi pen',2,4,'lexi-pens_1466746.png','blue pen'),
(4,150,'Badam',3,1,'badam.jpg','150rs per pack of 100g'),
(5,75,'Arabian dates',3,1,'medjool-dates.jpg','75rs per pack of 100g'),
(7,100,'Cashew nut',3,1,'raw-cashew-s10vn-3.jpg','100rs per pack of 100g'),
(8,20,'Onion',4,2,'onion.jpg','20rs per pack of 1/2 kg'),
(9,25,'Tomato',4,2,'tomato.jpg','25rs per pack of 1/2 kg'),
(10,7,'Ginger',4,2,'ginger.jpg','7rs per pack of 100g');

/*Table structure for table `rating` */

DROP TABLE IF EXISTS `rating`;

CREATE TABLE `rating` (
  `r_id` int(11) NOT NULL AUTO_INCREMENT,
  `login_id` int(11) DEFAULT NULL,
  `shop_id` int(11) DEFAULT NULL,
  `rating` float DEFAULT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`r_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `rating` */

insert  into `rating`(`r_id`,`login_id`,`shop_id`,`rating`,`date`) values 
(2,8,4,2,'2023-03-05'),
(3,8,2,3,'2023-03-05'),
(4,8,3,3,'2023-03-05');

/*Table structure for table `shop` */

DROP TABLE IF EXISTS `shop`;

CREATE TABLE `shop` (
  `shop_id` int(11) NOT NULL AUTO_INCREMENT,
  `login_id` int(11) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  `place` varchar(30) DEFAULT NULL,
  `post` varchar(30) DEFAULT NULL,
  `pin` bigint(20) DEFAULT NULL,
  `phone` bigint(20) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`shop_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `shop` */

insert  into `shop`(`shop_id`,`login_id`,`name`,`place`,`post`,`pin`,`phone`,`email`) values 
(1,2,'Amana Mall','Edappal','Edappal',679576,9876098980,'amanamall@gmail.com'),
(2,3,'Ajfan Dates','Edappal','Edappal',679576,8765987609,'ajfandates@gmail.com'),
(3,4,'Edappal groceries','Sukapuram','Sukapuram',679576,6789789089,'edappalgroceries@gmail.com'),
(4,5,'sasi','Edappal','Sukapuram',679576,8877665544,'edplgroceries@gmail.com');

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `login_id` int(11) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  `place` varchar(30) DEFAULT NULL,
  `pin` varchar(6) DEFAULT NULL,
  `phone` varchar(10) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `post` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `user` */

insert  into `user`(`user_id`,`login_id`,`name`,`place`,`pin`,`phone`,`email`,`post`) values 
(1,8,'Anuvind M','Edappal','679576','7356172874','anuvindm02@gmail.com','anuvindm02@gmail.com'),
(3,12,'Arun','parappuram','776655','7654321098','parappuramkamu@gmail.com','parappuramkamu@gmail.com'),
(4,13,'Akshay ','Kumbidi','679553','7306015685','akshaydilip72454@gmail.com','akshaydilip72454@gmail.com');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
