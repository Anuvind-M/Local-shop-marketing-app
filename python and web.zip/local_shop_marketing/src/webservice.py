import os
from flask import *
from werkzeug.utils import secure_filename

from src.dbconnectionnew import *

app=Flask(__name__)


@app.route('/register',methods=['post'])
def register():
    print(request.form)
    username = request.form['username']
    password = request.form['password']

    name = request.form['name']
    place = request.form['place']
    pin = request.form['pin']
    phone = request.form['phone']
    email = request.form['email']
    post = request.form['email']

    q = "INSERT INTO login VALUES(null,%s,%s,'user')"
    sval = (username, password)
    res = iud(q, sval)

    qry = "INSERT INTO `user` VALUES(NULL,%s,%s,%s,%s,%s,%s,%s)"
    val = (str(res), name, place,pin, phone, email,post)
    iud(qry, val)
    return jsonify({'task':"success"})


@app.route('/login',methods=['post'])
def login():
    print(request.form)
    username = request.form['username']
    password = request.form['password']
    q = "SELECT * FROM `login` WHERE `username`=%s AND `password`=%s"
    val = (username, password)
    res = selectone(q, val)

    if res is None:
        return jsonify({'task':"invalid"})
    else:
        print("kkkkkkkkkkkkkkkkkkkkkk")
        type=res['type']

        id=res['login_id']
        return jsonify({'task':"success", 'id':id , 'type':type })



@app.route('/viewshops',methods=['post'])
def viewshops():
    qry = "SELECT * FROM shop JOIN `login` ON `login`.`login_id`=`shop`.`login_id` WHERE `login`.`type`='shop'"
    res = selectall(qry)
    return jsonify(res)

#
# @app.route('/add_to_cart',methods=['post'])
# def add_to_cart():
#     userid = request.form['userid']
#     comp = request.form['comp']
#     return jsonify({'task':"success"})
#
#     qry="  SELECT `product`.*,`offer`.* FROM `category` JOIN `product`ON `category`.`category_id`=`product`.`c_id` LEFT JOIN  `offer` ON `offer`.`p_id`=`product`.`p_id`  WHERE `product`.`c_id`=%s"


@app.route('/view_product_details',methods=['post'])
def view_product_details():
    sid=request.form['lid']
    qry="    SELECT `product`.*,`offer`.*,`category`.* FROM `category` JOIN `product`ON `category`.`category_id`=`product`.`c_id` LEFT JOIN  `offer` ON `offer`.`p_id`=`product`.`p_id`  WHERE `product`.`shop_id`=%s"
    res = selectall2(qry,sid)
    print(res,"IIIIIIIIIIIIIIIII")
    return jsonify(res)

@app.route('/view_product_details2',methods=['post'])
def view_product_details2():
    sid=request.form['pid']
    qry = "SELECT * FROM product WHERE `p_id`=%s"
    res = selectall2(qry,sid)
    return jsonify(res)


@app.route('/view_products_selected_category',methods=['post'])
def view_products_selected_category():
    print(request.form)
    qry = "SELECT * FROM product where`c_id`=%s "
    res = selectall2(qry,request.form['cid'])
    print(res,"eeeeeeeeeee")
    return jsonify(res)


@app.route('/view_category',methods=['post'])
def view_category():
    qry = "SELECT * FROM `category`"
    res = selectall(qry)
    return jsonify(res)


@app.route('/shopselection',methods=['post'])
def shopselection():
    qry="SELECT * FROM shop"
    res = selectall(qry)
    return jsonify(res)


@app.route('/rateshops',methods=['post'])
def rateshops():
    lid = request.form['lid']
    shopid = request.form['shopid']

    qry1 = "SELECT * FROM `rating` WHERE `rating`.`login_id`=%s and `shop_id`=%s"
    val=(lid,shopid)
    res2 = selectone(qry1,val)
    print(res2)
    if res2 is None:

        rating = request.form['rating']
        qry = "INSERT INTO `rating` VALUES(NULL,%s,%s,%s,CURDATE())"
        sval = (lid, shopid,rating)
        res = iud(qry,sval)
    else:
        rating = request.form['rating']
        qry = "UPDATE `rating` SET `rating`=%s where r_id=%s"
        sval = (rating,res2['r_id'] )
        iud(qry, sval)

    return jsonify({'task': "success"})


@app.route('/order',methods=['post'])
def order():
    print(request.form)
    lid = request.form['lid']
    p_id = request.form['pid']
    quantity = request.form['quantity']
    q="SELECT * FROM  `product` WHERE `p_id`=%s"
    res=selectone(q,p_id)
    print (res,"gggggggggggggggggggggggg")

    price=res['price']
    total=int(quantity)*int(price)
    print(total,"OOOOOOOOOOOOOOOO")
    q="INSERT INTO `order` VALUES(NULL,%s,%s,'pending',curdate())"
    val=(lid,total)
    id=iud(q,val)

    q1="INSERT INTO `order_item` VALUES(NULL,%s,%s,%s,'pending',0)"
    v1=(str(id),p_id,quantity)
    iud(q1,v1)
    return jsonify({"task":"success"})





@app.route('/view_order_status',methods=['post'])
def view_order_status():
    print(request.form)
    lid=request.form['lid']
    qry="SELECT `order_item`.`quantity`,`product`.`p_name`,`image`,`order`.* FROM `order_item` JOIN `product` ON `order_item`.`pid`=`product`.`p_id` JOIN `order` ON `order_item`.`order_id`=`order`.`order_id` WHERE `order`.`user_id`=%s"
    res = selectall2(qry,lid)
    print(res)
    return jsonify(res)


@app.route('/sendcomplaint',methods=['post'])
def sendcomplaint():
    print(request.form)
    userid = request.form['userid']
    comp = request.form['comp']
    qry = "INSERT INTO `complaints` VALUES(NULL,%s,%s,CURDATE(),CURTIME(),'pending')"
    sval = (userid, comp)
    iud(qry, sval)
    return jsonify({"task":"success"})


@app.route('/viewcomplaint', methods=['post'])
def viewcomplaint():
    print(request.form)
    lid=request.form['lid']
    qry="SELECT * FROM `complaints` WHERE `user_id`=%s"
    res=selectall2(qry,lid)
    print(res)
    return jsonify(res)

@app.route('/viewcart', methods=['post'])
def viewcart():
    lid=request.form['lid']
    qry="SELECT `product`.*,`order_item`.* ,`order`.* FROM `order_item` JOIN `product` ON `order_item`.`pid`=`product`.`p_id`  JOIN `order` ON `order`.`order_id`=`order_item`.`order_id` WHERE `order`.`user_id`=%s AND `order`.`status`='cart'"

    res=selectall2(qry,lid)
    qry1="SELECT * FROM `order` WHERE `user_id`=%s AND `status`='cart' "
    res1=selectone(qry1,lid)
    print(res)
    return jsonify(data=res,data1=res1['amount'],data2=res1['order_id'])




# -------------------deliveryboy------------------------------
# @app.route('/delivery_register',methods=['post'])
# def delivery_register():
#     username = request.form['username']
#     password = request.form['password']
#
#     vehiclename = request.form['vehiclename']
#     phone = request.form['phone']
#     email = request.form['email']
#
#     q = "INSERT INTO login VALUES(null,%s,%s,'pending')"
#     sval = (username, password)
#     res = iud(q, sval)
#
#     qry = "INSERT INTO `user` VALUES(NULL,%s,%s,%s,%s,%s)"
#     val = (str(res), vehiclename, username, phone, email)
#     iud(qry, val)
#     return jsonify({'task':"success"})

@app.route('/view_assignedwork',methods=['post'])
def view_assignedwork():
    id = request.form['lid']
    qry="SELECT `assign`.*,`user`.*,`location`.*,`order`.*,`product`.`p_name` FROM `user` JOIN `order` ON `user`.`login_id`=`order`.`user_id` JOIN `assign` ON `assign`.`order_id`=`order`.`order_id` JOIN `location` ON `location`.`user_id`=`user`.`login_id` JOIN `order_item` ON `order`.`order_id`=`order_item`.`order_id` JOIN `product` ON `product`.`p_id`=`order_item`.`pid` WHERE `assign`.`status` IN ('assigned','On going') AND `boy_id`=%s"
    # qry = "SELECT `assign`.*,`user`.*,`location`.*,`order`.* FROM `user` JOIN `order` ON `user`.`login_id`=`order`.`user_id` JOIN `assign` ON `assign`.`order_id`=`order`.`order_id` JOIN `location` ON `location`.`user_id`=`user`.`login_id` WHERE `assign`.`status`='assigned' AND `boy_id`=%s GROUP BY `order`.`user_id`"
    res = selectall2(qry,id)
    print(res)
    return jsonify(res)


@app.route('/viewdeliveryaddress',methods=['post'])
def viewdeliveryaddress():
    lid=request.form['lid']
    qry = "    SELECT `assign`.*,`user`.*,`location`.* FROM `user` JOIN `order` ON `user`.`login_id`=`order`.`user_id` JOIN `assign` ON `assign`.`order_id`=`order`.`order_id` JOIN `location` ON `location`.`user_id`=`user`.`login_id` WHERE `assign`.`status`='assigned' AND `boy_id`=%s GROUP BY `order`.`user_id`"

    # qry="SELECT `order`.*,`user`.*,`assign`.* FROM `order` JOIN `user` ON `order`.`user_id`=`user`.`user_id` JOIN `assign` ON `assign`.`order_id`=`order`.`order_id` WHERE `assign`.`boy_id`=%s"
    res = selectall2(qry,lid)
    print (res)
    return jsonify(res)


@app.route('/statusupdation',methods=['post'])
def statusupdation():
    status = request.form['status']
    orderid = request.form['orderid']

    qry="UPDATE `assign` SET `status`=%s WHERE `order_id`=%s"
    val=(status,orderid)
    res=iud(qry,val)
    if(status=="Delivered"):
        qry="UPDATE `order` SET `status`='Delivered' WHERE `order_id`=%s"
        iud(qry,orderid)
    if (status == "On Going"):
        qry = "UPDATE `order` SET `status`='Shipped' WHERE `order_id`=%s"
        iud(qry, orderid)
    return jsonify({'task':"success"})

@app.route('/viewupdate',methods=['post'])
def viewupdate():
    lid=request.form['lid']
    qry="SELECT `user`.`name`,`product`.`p_name`,`order_item`.`amount`,`order`.`user_id`,`assign`.`assign_id`,`shop`.`name` AS shopname FROM `assign`JOIN `delivery_boy`ON `delivery_boy`.`login_id`=`assign`.`boy_id`JOIN  `order_item`ON `assign`.`order_id`=`order_item`.`item_id` JOIN `order`ON `order`.`order_id`=`order_item`.`order_id` JOIN `product`ON `product`.`p_id`=`order_item`.`pid` JOIN `user`ON `user`.`login_id`=`order`.`user_id` JOIN `shop`ON `product`.`shop_id`=`shop`.`shop_id` WHERE `assign`.`boy_id`=%s"
    res=selectall2(qry,lid)
    return jsonify(res)


@app.route('/locationupdation',methods=['post'])
def locationupdation():

    return jsonify()
# ///////////////////////////////////////////////////////

# @app.route('/Add_to_cart',methods=['post'])
# def Add_to_cart1():
#     print (request.form)
#     uid = request.form['lid']
#     pid = request.form['pid']
#     ofid = request.form['ofid']
#     qnty = request.form['qnty']
#
#     re = selectone("SELECT * FROM `offer` WHERE `offer_id`=%s ",(ofid))
#     print(re)
#     offr = re['offer']
#     off1 = offr.replace("%", "")
#     print(off1)
#     r = selectone("SELECT * FROM `product` WHERE `p_id`=%s",pid)
#     print(r['price'], "pppppppppppppppp")
#     dprice=int(r['price'])-((int(r['price'])*int(off1)))/100
#     print(dprice,"ddddddddddddddddddd")
#
#     res=selectone("SELECT * FROM `order` WHERE `user_id`=%s AND `status`='cart'",(uid))
#     if res is None:
#
#         rr = iud("INSERT INTO `order` (`user_id`,`amount`,`status`,`date`) VALUES(%s,0,'cart',curdate())",(uid))
#         iud("INSERT INTO `order_item` (`order_id`,`pid`,`quantity`,`date`,`status`) VALUES(%s,%s,%s,CURDATE(),'pending')",(rr,pid,qnty))
#
#         # iud("INSERT INTO `order_item` (`order_id`,`pid`,`quantity`,`date`,`status`,`offer`) VALUES(%s,%s,%s,CURDATE(),'pending',%s)",(rr,pid,qnty,dprice))
#         qry1 = "SELECT SUM(`order_item`.`offer`*`order_item`.`quantity`)AS tot FROM `product` JOIN `order_item`ON `product`.`p_id`=`order_item`.`pid` WHERE `order_item`.`order_id`=%s"
#         res3 = selectone(qry1, oid)
#         print(res3, "ttttttttttttttttttttt")
#         qry4 = " UPDATE `order` SET `amount`=%s WHERE `order_id`=%s"
#         val4 = (res3['tot'], oid)
#         print(val4, "===========================================================")
#         iud(qry4, val4)
#
#         return jsonify({'task': 'valid'})
#
#     else:
#         oid=res['order_id']
#         qry="INSERT INTO `order_item` VALUES(NULL,%s,%s,%s,'pending')"
#         val=(res['order_id'], pid, qnty)
#         iud(qry,val)
#
#         # iud("INSERT INTO `order_item` (`order_id`,`pid`,`quantity`,`date`,`status`,`offer`) VALUES(%s,%s,%s,CURDATE(),'pending',%s)",(res['order_id'], pid, qnty, dprice))
#         # qry1="SELECT SUM(`order_item`.`offer`*`order_item`.`quantity`)AS tot FROM `product` JOIN `order_item`ON `product`.`p_id`=`order_item`.`pid` WHERE `order_item`.`order_id`=%s"
#         qry1="        SELECT SUM(`order_item`.`quantity`)AS tot FROM `product` JOIN `order_item`ON `product`.`p_id`=`order_item`.`pid` WHERE `order_item`.`order_id`=%s"
#         res3=selectone(qry1,res['order_id'])
#         print(res3,"ttttttttttttttttttttt")
#         qry4=" UPDATE `order` SET `amount`=%s WHERE `order_id`=%s"
#         val4 = ( res3['tot'],res['order_id'])
#         print(val4,"===========================================================")
#         iud(qry4, val4)
#         return jsonify({'task': 'valid'})
#
# //////////////////////////////////////////////////////



@app.route('/Add_to_cart',methods=['post'])
def Add_to_cart():
    print (request.form)
    uid = request.form['lid']
    pid = request.form['pid']
    ofid = request.form['ofid']
    qnty = request.form['qnty']

    re = selectone("SELECT * FROM `offer` WHERE `offer_id`=%s AND CURDATE() <=`to_date`",(ofid))
    print(re,"++++++++++++++")
    off1=0
    if re is not None:
        offr = re['offer']
        off1 = offr.replace("%", "")
        print(off1)
    r = selectone("SELECT * FROM `product` WHERE `p_id`=%s",pid)
    print(r['price'], "pppppppppppppppp")
    dprice=int(r['price'])-((int(r['price'])*int(off1)))/100
    print(dprice,"ddddddddddddddddddd")

    res=selectone("SELECT * FROM `order` WHERE `user_id`=%s AND `status`='cart'",(uid))
    if res is None:
        # oid=res['order_id']
        # print(res,"$$$$$$$$$$$")


        rr = iud("INSERT INTO `order` (`user_id`,`amount`,`status`,date) VALUES(%s,%s,'cart',curdate())",(uid,dprice))
        qry="INSERT INTO `order_item`VALUES(null,%s,%s,%s,'pending',%s)"
        val1=(rr,pid,qnty,dprice)
        res=iud(qry,val1)

        # iud("INSERT INTO `order_item` (`order_id`,`pid`,`quantity`,`status`,`offer`) VALUES(%s,%s,%s,'pending',%s)",(rr,pid,qnty,dprice))
        qry1 = "SELECT SUM(`order_item`.`offer`*`order_item`.`quantity`)AS tot FROM `product` JOIN `order_item`ON `product`.`p_id`=`order_item`.`pid` WHERE `order_item`.`order_id`=%s"
        res3 = selectone(qry1, res)
        print(res3, "ttttttttttttttttttttt")
        qry4 = " UPDATE `order` SET `amount`=%s WHERE `order_id`=%s"
        val4 = (res3['tot'],  res)
        print(val4, "===========================================================")
        iud(qry4, val4)

        return jsonify({'task': 'valid'})

    else:
        oid=res['order_id']
        qry=" INSERT INTO `order_item`  VALUES(null,%s,%s,%s,'pending',%s)"
        val=( res['order_id'], pid, qnty, dprice)
        iud(qry,val)

        # iud("INSERT INTO `order_item` (`order_id`,`pid`,`quantity`,`date`,`status`,`offer`) VALUES(%s,%s,%s,CURDATE(),'pending',%s)",(res['order_id'], pid, qnty, dprice))
        qry1="SELECT SUM(`order_item`.`offer`*`order_item`.`quantity`)AS tot FROM `product` JOIN `order_item`ON `product`.`p_id`=`order_item`.`pid` WHERE `order_item`.`order_id`=%s"
        res3=selectone(qry1,res['order_id'])
        print(res3,"ttttttttttttttttttttt")
        qry4=" UPDATE `order` SET `amount`=%s WHERE `order_id`=%s"
        val4 = ( res3['tot'],res['order_id'])
        print(val4,"===========================================================")
        iud(qry4, val4)
        return jsonify({'task': 'valid'})

    # else:
    #     oid=res['order_id']
    #     # print (oid,"_________________________")
    #
    #
    # qry2 = "INSERT INTO `order_item` VALUES (NULL,%s,%s,%s,CURDATE(),'ordered',%s)"
    # val2 = (str(oid), pid, qnty,ofid)
    # iud(qry2, val2)
    # # return jsonify({'task': 'valid'})
    #
    # qry3 = "SELECT SUM(`product`.`price`*`order_item`.`quantity`)AS tot FROM `product` JOIN `order_item`ON `product`.`p_id`=`order_item`.`pid` WHERE `order_item`.`order_id`=%s"
    #
    # res3 = selectone(qry3, oid)
    # print(res3)
    # qry4=" UPDATE `order` SET `amount`=%s WHERE `order_id`=%s"
    # val4 = ( res3['tot'],oid)
    # print(val4,"===========================================================")
    # iud(qry4, val4)
    return jsonify({'task':'valid'})


@app.route('/order123', methods=['post'])
def order123():
    oid=request.form['lid']
    qry1="UPDATE `order` SET `status`='pending' WHERE `order_id`=%s"
    val1=(oid)
    iud(qry1,val1)
    return jsonify({'task':'valid'})

@app.route('/order1234', methods=['post'])
def order1234 ():
    oid=request.form['lid']
    qry1="UPDATE `order` SET `status`='payed' WHERE `order_id`=%s"
    val1=(oid)
    iud(qry1,val1)
    return jsonify({'task':'valid'})

@app.route('/order34', methods=['post'])
def order34 ():
    oid=request.form['lid']
    qnt=request.form['qnt']

    qry1="INSERT INTO `order` VALUES(NULL,%s,%s,payed,CURDATE())"
    val1=(oid,qnt)
    iud(qry1,val1)
    return jsonify({'task':'valid'})




# ///////////////////////////


@app.route('/updatelocation',methods=['post'])
def updatelocation():
    print(request.form)
    lid = request.form['lid']
    lati = request.form['lat']
    longi = request.form['long']
    qry="SELECT * FROM `location` WHERE `user_id`=%s"
    res=selectone(qry,lid)
    if res is None:
        qry="INSERT INTO `location` VALUES(NULL,%s,%s,%s)"
        val=(lid,lati,longi)
        iud(qry,val)
    else:
        qry="UPDATE `location` SET `latitude`=%s,`longitude`=%s WHERE `user_id`=%s"
        val=(lati,longi,lid)
        iud(qry,val)
    return jsonify(status='send')

app.run(port='5000',host='0.0.0.0')

