import os
from flask import *
from werkzeug.utils import secure_filename

from src.dbconnectionnew import *

app=Flask(__name__)
app.secret_key="sdfgrt"


import functools

def login_required(func):
    @functools.wraps(func)
    def secure_function():
        if "lid" not in session:
            return render_template('loginindex.html')
        return func()

    return secure_function


@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

@app.route('/')
def login():
    return render_template('loginindex.html')

@app.route('/login_post',methods=['post'])
def login_post():
    uname=request.form['textfield']
    psw=request.form['textfield2']
    q="SELECT * FROM `login` WHERE `username`=%s AND `password`=%s"
    val=(uname,psw)
    res=selectone(q,val)

    if res is None:
        return '''<script>alert("Invalid username or password");window.location='/'</script>'''
    elif res['type']=='admin':
        session['lid']=res['login_id']

        return '''<script>alert("Admin home");window.location='/adminhome'</script>'''
    elif res['type']=='shop':
        session['lid']=res['login_id']
        return '''<script>alert("Shop home");window.location='/ShopHome'</script>'''
    else:
        return '''<script>alert("Invalid user");window.location='/'</script>'''

#=========================================ADMIN=============================
@app.route('/adminhome')
@login_required

def adminhome():
    return render_template('admin/admin home.html')

@app.route('/AcceptShop')
@login_required

def AcceptShop():
    id=request.args.get('id')
    qry="UPDATE `login` SET `type`='shop' WHERE `login_id`= %s"
    iud(qry,id)
    return '''<script>alert("Accepted ");window.location='/ApproveShop'</script>'''

@app.route('/RejectShop')
@login_required
def RejectShop():
    id=request.args.get('id')
    qry="UPDATE `login` SET `type`='rejected' WHERE `login_id`= %s"
    iud(qry,id)
    return '''<script>alert("Rejected");window.location='/ApproveShop'</script>'''

@app.route('/ApproveShop')
@login_required

def ApproveShop():
    q="SELECT `login`.*,`shop`.* FROM `login` JOIN `shop` ON `login`.`login_id`=`shop`.`login_id` WHERE `login`.`type`!='rejected'"
    res=selectall(q)
    return render_template('admin/Approve shop.html',data=res)


@app.route('/ManageProduct1')
@login_required

def ManageProduct1():
    q="SELECT *FROM category"
    res=selectall(q)
    print(res)
    return render_template('admin/Manage product categories 1.html',data=res)

@app.route('/delete_category')
@login_required

def delete_category():
    id=request.args.get('id')
    qry="DELETE FROM `category` WHERE `category_id`=%s"
    iud(qry,id)
    return '''<script>alert("Deleted");window.location='ManageProduct1'</script>'''

@app.route('/addProduct1',methods=['post'])
@login_required

def addProduct1():
    return render_template('admin/Manage product categories 2.html')


@app.route('/adminManageProduct2',methods=['post'])
@login_required

def adminManageProduct2():
    category = request.form['textfield']
    # details = request.form['textfield2']
    q="INSERT INTO `category` VALUES (NULL,%s)"
    sval=(category)
    iud(q,sval)
    return '''<script>alert("Added");window.location='ManageProduct1'</script>'''



@app.route('/ViewComplaint1')
@login_required

def ViewComplaint1():
    q="SELECT `user`.*,`complaints`.* FROM `user` JOIN `complaints` ON `user`.login_id=`complaints`.user_id WHERE `reply`='pending'"
    res=selectall(q)
    print(res)
    return render_template('admin/View complaint and send reply.html',data=res)

@app.route('/ViewComplaint2')
@login_required

def ViewComplaint2():
    id=request.args.get('rid')
    session['C_id']=id
    return render_template('admin/View complaint and send reply 2.html')


@app.route('/ViewComplaint21',methods=['post'])
@login_required

def ViewComplaint21():
    reply=request.form['textarea']
    qry="UPDATE `complaints` SET `reply`=%s WHERE `c_id`=%s"
    val=(reply,session['C_id'])
    iud(qry,val)
    return '''<script>alert("Sended successfully");window.location='/ViewComplaint1'</script>'''



@app.route('/ViewBoy')
@login_required

def ViewBoy():
    q="SELECT *FROM delivery_boy"
    res=selectall(q)
    print(res)
    return render_template('admin/View delivery boy.html',data=res)

@app.route('/ViewRating')
@login_required

def ViewRating():
    q="SELECT `rating`.*,`shop`.*,`user`.`name` AS `uname` FROM `rating` JOIN `shop` ON `rating`.`shop_id`=`shop`.`login_id` JOIN `user` ON  `user`.login_id=`rating`.login_id"
    res=selectall(q)
    return render_template('admin/View rating.html',data=res)

@app.route('/ViewUsers')
@login_required

def ViewUsers():
    q="SELECT *FROM `user`"
    res=selectall(q)
    print(res)
    return render_template('admin/View users.html',data=res)
@app.route('/DeleteUser')
def DeleteUser():

    id=request.args.get('id')
    q="DELETE FROM `login` WHERE `login_id`=%s"
    iud(q,id)
    qry = "DELETE FROM `user` WHERE `login_id`=%s"
    iud(qry, id)
    return '''<script>alert("Deleted");window.location='ViewUsers'</script>'''




#===========================SHOP===================================
@app.route('/Sign_up')
def Sign_up():
    return render_template('sign_up_index.html')

@app.route('/Sign_up_post',methods=['post'])
def Sign_up_post():
    username=request.form['textfield7']
    psw=request.form['textfield8']
    q="INSERT INTO login VALUES(null,%s,%s,'pending')"
    sval=(username,psw)
    res=iud(q,sval)

    shopname=request.form['textfield']
    place=request.form['textfield2']
    post=request.form['textfield3']
    pin=request.form['textfield4']
    phone=request.form['textfield5']
    email=request.form['textfield6']

    qry="INSERT INTO `shop` VALUES(NULL,%s,%s,%s,%s,%s,%s,%s)"
    val=(str(res),shopname,place,post,pin,phone,email)
    iud(qry,val)
    return '''<script>alert("Registered successfully");window.location='/'</script>'''


@app.route('/ShopHome')
@login_required

def ShopHome():
    return render_template('shop/shop home.html')

@app.route('/manage_delivery_boy',methods=['post','get'])
@login_required

def manage_delivery_boy():
    q="SELECT * FROM delivery_boy JOIN shop ON `shop`.`shop_id`=`delivery_boy`.`sh_id` WHERE `shop`.`shop_id`=%s"
    res = selectall2(q, session['lid'])
    return render_template('shop/manage_delivery_boy.html',data=res)

@app.route('/manage_delivery_boy2',methods=['post'])
@login_required

def manage_delivery_boy2():

    return render_template('shop/manage_delivery_boy 2.html')

@app.route('/edit_delivery_boy',methods=['get'])
@login_required

def edit_delivery_boy():
    id=request.args.get('id')
    session['did']=id
    qry = "SELECT * FROM `delivery_boy` WHERE `login_id`=%s"
    res=selectone(qry,id)

    return render_template('shop/edit_delivery_boy 2.html',val=res)

@app.route('/update_delivery_boy',methods=['post'])
@login_required

def update_delivery_boy():
    name = request.form['textfield']
    vehicle = request.form['textfield2']
    phone = request.form['textfield3']
    email = request.form['textfield4']

    q="UPDATE `delivery_boy` SET `vehicle name`=%s,`boy_name`=%s,`phone`=%s,`email`=%s WHERE `login_id`=%s"
    val=(vehicle,name,phone,email,session['did'])
    iud(q,val)
    return '''<script>alert("Edited successfully");window.location='/manage_delivery_boy'</script>'''


@app.route('/delete_delivery_boy',methods=['post','get'])
@login_required

def delete_delivery_boy():
    id=request.args.get('id')
    qry="delete from `login` where `login_id`=%s"
    iud(qry,id)
    qry = "delete from `delivery_boy` where `login_id`=%s"
    iud(qry,id)
    return '''<script>alert("Deleted successfully");window.location='/manage_delivery_boy'</script>'''



@app.route('/Add_deliveryboy', methods=['post'])
@login_required

def Add_deliveryboy():
    name = request.form['textfield']
    vehicle = request.form['textfield2']
    phone = request.form['textfield3']
    email = request.form['textfield4']
    username = request.form['textfield5']
    password = request.form['textfield6']
    q="INSERT INTO `login` VALUES (null,%s,%s,'delivery_agent')"
    sval=(username,password)
    lid=iud(q,sval)
    qry = "INSERT INTO `delivery_boy` VALUES (null,%s,%s,%s,%s,%s,%s)"
    val=(lid,session['lid'],vehicle,name,phone,email)
    iud(qry,val)
    return '''<script>alert("Added successfully");window.location='/manage_delivery_boy'</script>'''

@app.route('/ManageOffer')
@login_required

def ManageOffer():
    qry="SELECT `offer`.*,`product`.* FROM `product` JOIN `offer`ON `product`.`p_id`=`offer`.`p_id`  WHERE `product`.`shop_id`=%s"
    res=selectall2(qry,session['lid'])
    return render_template('shop/Add and manage offers.html',val=res)

# @app.route('/ManageOffer')
# def ManageOffer():
#     q="SELECT `offer`.*,`product`.* FROM `offer` JOIN `product` ON `offer`.`p_id`=`product`.`p_id` WHERE `product`.`shop_id`=%s"
#     res=selectall2(q,session['lid'])
#     print(res)
#     return render_template('shop/Add and manage offers.html',data=res)

@app.route('/ManageOffer2',methods=['post'])
@login_required

def ManageOffer2():
    qry="SELECT * FROM `product`WHERE `product`.`shop_id`=%s"
    res=selectall2(qry,session['lid'])
    res1=selectall("SELECT CURDATE() AS d")
    return render_template('shop/Add and manage offers 2.html',data=res,d=res1[0]['d'])

@app.route('/ManageOffer3',methods=['post'])
@login_required
def ManageOffer3():
    product=request.form['pro']
    offer=request.form['textfield']
    offer_details=request.form['textfield2']
    from_date=request.form['textfield3']
    to_date=request.form['textfield4']
    qry="INSERT INTO `offer` VALUES(%s,%s,%s,%s,NULL,%s)"
    val=(product,offer,offer_details,from_date,to_date)
    iud(qry,val)

    return '''<script>alert("Added successfully");window.location='/ManageOffer'</script>'''


# @app.route('/AddOffer',methods=['post'])
# def AddOffer():
#     offer=request.form['textfield']
#     offer_details=request.form['textfield2']
#     pid=request.form['select']
#
#     q="SELECT * FROM `offer` WHERE `p_id`=%s"
#     res=selectone(q,pid)
#     if res is None:
#         qry="INSERT INTO `offer` VALUES (%s,%s,%s,%s,NULL)"
#         val=(pid,offer,offer_details,session['lid'])
#         iud(qry,val)
#         return '''<script>alert("Added successfully");window.location='/ManageOffer'</script>'''
#     else:
#         q1="UPDATE `offer` SET `offer`=%s,`offer_details`=%s WHERE `p_id`=%s"
#         val1=(offer,offer_details,pid)
#         iud(q1,val1)
#         return '''<script>alert("Updated successfully");window.location='/ManageOffer'</script>'''
#
@app.route('/DeleteOffer')
@login_required

def DeleteOffer():
    id=request.args.get('id')
    q="DELETE FROM `offer` WHERE `offer_id`=%s"
    iud(q,id)
    return '''<script>alert("Deleted");window.location='ManageOffer'</script>'''


@app.route('/ManageProduct')
@login_required

def ManageProduct():
    q="SELECT `product`.*,`category`.* FROM `product` JOIN `category` ON `product`.`c_id`=`category`.`category_id` WHERE shop_id=%s"
    res=selectall2(q,session['lid'])
    return render_template('shop/Manage product.html',data=res)

@app.route('/ManageProduct2',methods=['post'])
@login_required

def ManageProduct2():
    q="SELECT *FROM `category`"
    res=selectall(q)
    return render_template('shop/Manage product 2.html',data=res)

@app.route('/DeleteProduct')
@login_required

def DeleteProduct():

    id=request.args.get('id')
    q="DELETE FROM `product` WHERE `p_id`=%s"
    iud(q,id)
    return '''<script>alert("Deleted");window.location='ManageProduct'</script>'''

@app.route('/editproduct')
@login_required

def editproduct():
    q = "SELECT *FROM `category`"
    res1 = selectall(q)
    id=request.args.get('id')
    session['pid']=id
    q="SELECT *FROM product WHERE p_id=%s"
    res=selectone(q,id)
    return render_template("shop/editproduct.html",i=res,data=res1)


@app.route('/updateProduct',methods=['post'])
@login_required

def updateProduct():
    try:
        product_name=request.form['textfield']
        price=request.form['textfield2']
        details=request.form['textfield3']
        image=request.files['image']
        imname=secure_filename(image.filename)
        image.save(os.path.join('static/product',imname))
        category_id=request.form['select']
        q="UPDATE `product` SET price=%s, p_name=%s, c_id=%s, image=%s, details=%s WHERE p_id=%s"
        val=(price,product_name,category_id,imname,details,session['pid'])
        iud(q,val)
        return '''<script>alert("Updated successfully");window.location='/ManageProduct'</script>'''
    except Exception as e:
        product_name = request.form['textfield']
        price = request.form['textfield2']
        details = request.form['textfield3']

        category_id = request.form['select']
        q = "UPDATE `product` SET price=%s, p_name=%s, c_id=%s, details=%s WHERE p_id=%s"
        val = (price, product_name, category_id, details, session['pid'])
        iud(q, val)
        return '''<script>alert("Updated successfully");window.location='/ManageProduct'</script>'''



@app.route('/AddProduct',methods=['post'])
@login_required

def AddProduct():
    product_name=request.form['textfield']
    price=request.form['textfield2']
    details=request.form['textfield3']
    image=request.files['image']
    imname=secure_filename(image.filename)
    image.save(os.path.join('static/product',imname))
    category_id=request.form['select']
    qry = "INSERT INTO `product` VALUES (NULL,%s,%s,%s,%s,%s,%s)"
    val = (price, product_name, session['lid'], category_id,imname,details)
    iud(qry, val)
    return '''<script>alert("Added successfully");window.location='/ManageProduct'</script>'''


@app.route('/DeliveryStatus')
@login_required

def DeliveryStatus():
    q="SELECT `user`.`name`,`product`.`p_name`,`delivery_boy`.`boy_name`,`order`.`status` FROM `order` JOIN `user` ON `order`.`user_id`=`user`.`login_id` JOIN `order_item` ON `order`.`order_id`=`order_item`.`order_id` JOIN `product` ON `order_item`.`pid`=`product`.`p_id` JOIN `assign` ON `order`.`order_id`=`assign`.`order_id` JOIN `delivery_boy` ON `assign`.`boy_id`=`delivery_boy`.`login_id`"
    res=selectall(q)
    return render_template('shop/View delivery status.html',data=res)

@app.route('/OrderAssign')
@login_required

def OrderAssign():
    q="SELECT `user`.`name`,`order`.* FROM `order` JOIN `user` ON `order`.`user_id`=`user`.`login_id` JOIN `order_item` ON `order`.`order_id`=`order_item`.`order_id` JOIN `product` ON `order_item`.`pid`=`product`.`p_id` WHERE `product`.`shop_id`=%s  and `order`.`status`='pending' GROUP BY `order`.`order_id` "
    res=selectall2(q,session['lid'])
    return render_template('shop/View order and assign.html',data=res)

@app.route('/view_order_details2')
@login_required

def view_order_details2():
    id = request.args.get('id')
    qry = "SELECT `product`.`p_name`,`order_item`.`quantity` FROM `order_item` JOIN `product` ON `order_item`.`pid`=`product`.`p_id` WHERE `order_item`.`order_id`=%s"
    res = selectall2(qry,id)
    return render_template('shop/View order details.html', data=res)

@app.route('/OrderAssign2')
@login_required

def OrderAssign2():
    id=request.args.get('id')
    session['order_id']=id
    qry = "SELECT * FROM delivery_boy JOIN shop ON `shop`.`shop_id`=`delivery_boy`.`sh_id` WHERE `shop`.`shop_id`=%s"
    res = selectall2(qry,session['lid'])
    return render_template('shop/View order and assign 2.html',data=res)

@app.route('/Assigndeliveryboy',methods=['post'])
@login_required

def Assigndeliveryboy():

    boy_id = request.form['select']
    qry="INSERT INTO `assign` VALUES(NULL,%s,%s,CURDATE(),'assigned')"
    val=(session['order_id'],boy_id)
    iud(qry,val)

    qry = "UPDATE `order` SET `status`='ordered' WHERE `order_id`=%s"
    iud(qry,session['order_id'])

    return '''<script>alert("Added successfully");window.location='/OrderAssign'</script>'''




@app.route('/Rating')
@login_required

def Rating():
    q="SELECT `rating`.`rating`,`rating`.`date`,`user`.`name` FROM `rating` JOIN `user` ON `rating`.`login_id`=`user`.`login_id`WHERE `rating`.`shop_id`=%s"
    res=selectall2(q,session['lid'])
    return render_template('shop/View shop rating.html',data=res)

@app.route('/add_to_cart')
def add_to_cart():

    return


app.run(debug=-True)