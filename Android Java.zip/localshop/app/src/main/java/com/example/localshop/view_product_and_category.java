package com.example.localshop;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.StrictMode;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class view_product_and_category extends AppCompatActivity implements AdapterView.OnItemSelectedListener, AdapterView.OnItemClickListener {
    SharedPreferences sh;
    ArrayList <String> productname,image,category,details,cat,cid,pid,price;
    String url,url1,ccid,ctgry;
    ListView l1;
    Spinner s1;
    Button b1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_product_and_category);
        l1 = findViewById(R.id.listview1);
        s1 = findViewById(R.id.spinner2);
        b1 = findViewById(R.id.button22);





        url1 = "http://" + sh.getString("ip", "") + ":5000/view_category";
        RequestQueue queue = Volley.newRequestQueue(view_product_and_category.this);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url1, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                // Display the response string.
                Log.d("+++++++++++++++++", response);
                try {

                    JSONArray ar = new JSONArray(response);

                    cat = new ArrayList<>();
                    cid = new ArrayList<>();



                    for (int i = 0; i < ar.length(); i++) {
                        JSONObject jo = ar.getJSONObject(i);
                        cat.add(jo.getString("category"));
                        cid.add(jo.getString("category_id"));



                    }

                     ArrayAdapter<String> ad=new ArrayAdapter<>(view_product_and_category.this,android.R.layout.simple_spinner_dropdown_item,cat);
                    s1.setAdapter(ad);

                    s1.setOnItemSelectedListener(view_product_and_category.this);

//                    l1.setAdapter(new custom4(view_product_and_category.this, productname, image, category, details));
//                    l1.setOnItemClickListener(view_menu.this);

                } catch (Exception e) {
                    Log.d("=========", e.toString());
                }


            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(view_product_and_category.this, "err" + error, Toast.LENGTH_SHORT).show();
            }
        }) {
            @NonNull
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
//
//            SharedPreferences.Editor edp = sh.edit();
//            edp.putString("cid", cid);
//            edp.apply();
            return params;
            }
        };
        queue.add(stringRequest);

b1.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {

        ctgry = s1.getSelectedItem().toString();

//        Toast.makeText(view_product_and_category.this, ""+ctgry, Toast.LENGTH_SHORT).show();

        url = "http://" + sh.getString("ip", "") + ":5000/view_products_selected_category";
        RequestQueue queue = Volley.newRequestQueue(view_product_and_category.this);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                // Display the response string.
                Log.d("+++++++++++++++++", response);
                try {

//                    Toast.makeText(view_product_and_category.this, ""+response, Toast.LENGTH_SHORT).show();

                    JSONArray ar = new JSONArray(response);

                    productname = new ArrayList<>();
                    image = new ArrayList<>();
                    pid  = new ArrayList<>();
                    price  = new ArrayList<>();
//                    category  = new ArrayList<>();
                    details  = new ArrayList<>();


                    for (int i = 0; i < ar.length(); i++) {
                        JSONObject jo = ar.getJSONObject(i);
                        productname.add(jo.getString("p_name"));
                        image.add(jo.getString("image"));

                        details.add(jo.getString("details"));
                        pid.add(jo.getString("p_id"));
                        price.add(jo.getString("price"));
//                        category.add(jo.getString("category"));


                    }

                    // ArrayAdapter<String> ad=new ArrayAdapter<>(Home.this,android.R.layout.simple_list_item_1,name);
                    //lv.setAdapter(ad);

                    l1.setAdapter(new CustomViewProductCategory(view_product_and_category.this, productname, image,details));
                    l1.setOnItemClickListener(view_product_and_category.this);

                } catch (Exception e) {
                    Log.d("=========", e.toString());

                }


            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(view_product_and_category.this, "err" + error, Toast.LENGTH_SHORT).show();
            }
        }) {
            @NonNull
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("cid",ccid);
                return params;
            }
        };
        queue.add(stringRequest);
    }
});

    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        ccid=cid.get(i);
//

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        Intent ii=new Intent(getApplicationContext(), Product_details.class);
        ii.putExtra("p_id",pid.get(i));
        ii.putExtra("image",image.get(i));
        ii.putExtra("price",price.get(i));
        ii.putExtra("category",ctgry);
        ii.putExtra("details",details.get(i));
        ii.putExtra("product",productname.get(i));
        startActivity(ii);

    }
}