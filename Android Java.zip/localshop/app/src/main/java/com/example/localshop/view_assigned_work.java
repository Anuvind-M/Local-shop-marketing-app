package com.example.localshop;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class view_assigned_work extends AppCompatActivity implements AdapterView.OnItemClickListener{
    SharedPreferences sh;
    ArrayList <String> username,date,product,aid,price;
    String aaid;
    String url;
    ListView l1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        sh= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_assigned_work);
        l1=findViewById(R.id.listview);

        url = "http://" + sh.getString("ip", "") + ":5000/view_assignedwork";
        RequestQueue queue = Volley.newRequestQueue(view_assigned_work.this);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                // Display the response string.
                Log.d("+++++++++++++++++", response);
                try {
                    Toast.makeText(view_assigned_work.this, response+"", Toast.LENGTH_SHORT).show();

                    JSONArray ar = new JSONArray(response);

                    username = new ArrayList<>();
//                    shopname = new ArrayList<>();
                    date = new ArrayList<>();
                    product = new ArrayList<>();
                    price = new ArrayList<>();
                    aid = new ArrayList<>();







                    for (int i = 0; i < ar.length(); i++) {
                        JSONObject jo = ar.getJSONObject(i);
                        username.add(jo.getString("name"));
//                        shopname.add(jo.getString("name"));
                        date.add(jo.getString("date"));
                        product.add(jo.getString("p_name"));
                        price.add(jo.getString("amount"));
                        aid.add(jo.getString("order_id"));




                    }

                    // ArrayAdapter<String> ad=new ArrayAdapter<>(Home.this,android.R.layout.simple_list_item_1,name);
                    //lv.setAdapter(ad);

                    l1.setAdapter(new custom4(view_assigned_work.this, username, date,product,price));
                    l1.setOnItemClickListener(view_assigned_work.this);

                } catch (Exception e) {
                    Log.d("=========", e.toString());
                }


            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(view_assigned_work.this, "err" + error, Toast.LENGTH_SHORT).show();
            }
        }) {
            @NonNull
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("lid", sh.getString("lid", ""));
                return params;
            }
        };
        queue.add(stringRequest);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        aaid=aid.get(position);


//        Intent ii=new Intent(getApplicationContext(), update_status.class);
//        startActivity(ii);
        AlertDialog.Builder ald=new AlertDialog.Builder(view_assigned_work.this);
        ald.setTitle("Update status")
                .setPositiveButton(" Update ", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                        try
                        {





                            Intent ik = new Intent(getApplicationContext(), update.class);
                            ik.putExtra("aid",aaid);

                            startActivity(ik);



                        }
                        catch(Exception e)
                        {
                            Toast.makeText(getApplicationContext(),e+"",Toast.LENGTH_LONG).show();
                        }

                    }
                })
                .setNegativeButton(" cancel", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {

                        Intent ii = new Intent(getApplicationContext(), view_assigned_work.class);
                        startActivity(ii);
                    }
                });

        AlertDialog al=ald.create();
        al.show();
    }
}