package com.example.localshop;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.StrictMode;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class View_product extends AppCompatActivity implements AdapterView.OnItemClickListener{
    SharedPreferences sh;
    ArrayList <String> product,image,pid,price,details,category,offer,offer_id,offer_details;
    String url;
    ListView l1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        sh= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_product);
        l1=findViewById(R.id.listview);
        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }


        url = "http://" + sh.getString("ip", "") + ":5000/view_product_details";
        RequestQueue queue = Volley.newRequestQueue(View_product.this);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                // Display the response string.
                Log.d("+++++++++++++++++", response);
                try {

//                    Toast.makeText(View_product.this, ""+response, Toast.LENGTH_SHORT).show();

                    JSONArray ar = new JSONArray(response);

                    product = new ArrayList<>();
                    image = new ArrayList<>();
                    pid  = new ArrayList<>();
                    price  = new ArrayList<>();
                    category  = new ArrayList<>();
                    details  = new ArrayList<>();
                    offer  = new ArrayList<>();
                    offer_details  = new ArrayList<>();

                    offer_id  = new ArrayList<>();


                    for (int i = 0; i < ar.length(); i++) {
                        JSONObject jo = ar.getJSONObject(i);
                        product.add(jo.getString("p_name"));
                        image.add(jo.getString("image"));
                        pid.add(jo.getString("p_id"));
                        price.add(jo.getString("price"));
                        category.add(jo.getString("category"));
                        details.add(jo.getString("details"));
                        offer.add(jo.getString("offer"));
                        offer_details.add(jo.getString("offer_details"));

                        offer_id.add(jo.getString("offer_id"));



                    }

                    // ArrayAdapter<String> ad=new ArrayAdapter<>(Home.this,android.R.layout.simple_list_item_1,name);
                    //lv.setAdapter(ad);

                    l1.setAdapter(new custom2(View_product.this,product, image));
                    l1.setOnItemClickListener(View_product.this);

                } catch (Exception e) {
                    Log.d("=========", e.toString());
                }


            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(View_product.this, "err" + error, Toast.LENGTH_SHORT).show();
            }
        }) {
            @NonNull
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("lid", getIntent().getStringExtra("slid"));
                return params;
            }
        };
        queue.add(stringRequest);
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        Intent ii=new Intent(getApplicationContext(), Product_details.class);
        ii.putExtra("p_id",pid.get(i));
        ii.putExtra("image",image.get(i));
        ii.putExtra("price",price.get(i));
        ii.putExtra("category",category.get(i));
        ii.putExtra("details",details.get(i));
        ii.putExtra("product",product.get(i));
        ii.putExtra("offer",offer.get(i));
        ii.putExtra("offer_details",offer_details.get(i));
        ii.putExtra("offer_id",offer_id.get(i));


        startActivity(ii);
    }
}