package com.example.localshop;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.StrictMode;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Product_details extends AppCompatActivity {
    TextView t1,t2,t3,t4,t5,t6;
    EditText e1;
    Button b1,b2,b3,b4;
    String url1;
    ArrayList<String> product,price,details,image,category;
    SharedPreferences sh;
    String quantity,url;
    ImageView im;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        sh= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_details);
        e1=findViewById(R.id.editTextTextPersonName11);
        t1=findViewById(R.id.textView64);
        t2=findViewById(R.id.textView65);
        t3=findViewById(R.id.textView67);
        t4=findViewById(R.id.textView68);
        t5=findViewById(R.id.textView79);
        t6=findViewById(R.id.textView81);

        e1=findViewById(R.id.editTextTextPersonName11);
        b1=findViewById(R.id.button6);
        b2 = findViewById(R.id.button5);
        b3 = findViewById(R.id.button25);
        b4=findViewById(R.id.button28);


        int amt = Integer.parseInt(getIntent().getStringExtra("price"));

        im = findViewById(R.id.imageView);

                    if(android.os.Build.VERSION.SDK_INT>9)
                        {
                            StrictMode.ThreadPolicy policy=new StrictMode.ThreadPolicy.Builder().permitAll().build();
                            StrictMode.setThreadPolicy(policy);
                        }


                        t1.setText(getIntent().getStringExtra("product"));
                        t2.setText(getIntent().getStringExtra("price"));
                        t3.setText(getIntent().getStringExtra("details"));
                        t4.setText(getIntent().getStringExtra("category"));
                        t5.setText(getIntent().getStringExtra("offer")+"%");
                        t6.setText(getIntent().getStringExtra("offer_details"));



        java.net.URL thumb_u;
                        try {

                            //thumb_u = new java.net.URL("http://192.168.43.57:5000/static/photo/flyer.jpg");

                            thumb_u = new java.net.URL("http://"+sh.getString("ip","")+":5000/static/product/"+getIntent().getStringExtra("image"));
                            Drawable thumb_d = Drawable.createFromStream(thumb_u.openStream(), "src");
                            im.setImageDrawable(thumb_d);

                        }
                        catch (Exception e)
                        {
                            Log.d("errsssssssssssss",""+e);
                        }







        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                quantity = e1.getText().toString();
                if (quantity.equalsIgnoreCase("")) {
                    e1.setError("Enter your Quantity");

                } else {


                    RequestQueue queue = Volley.newRequestQueue(Product_details.this);
                    url = "http://" + sh.getString("ip", "") + ":5000/order";

                    // Request a string response from the provided URL.
                    StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            // Display the response string.
                            Log.d("+++++++++++++++++", response);
                            try {
                                JSONObject json = new JSONObject(response);
                                String res = json.getString("task");

                                if (res.equalsIgnoreCase("success")) {
//                                String lid = json.getString("id");
//                                SharedPreferences.Editor edp = sh.edit();
//                                edp.putString("lid", lid);
//                                edp.commit();
                                    Intent ik = new Intent(getApplicationContext(), userhome.class);
                                    startActivity(ik);
                                    Toast.makeText(Product_details.this, "success ", Toast.LENGTH_SHORT).show();


                                } else {

                                    Toast.makeText(Product_details.this, "Invalid", Toast.LENGTH_SHORT).show();

                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }


                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {


                            Toast.makeText(getApplicationContext(), "Error" + error, Toast.LENGTH_LONG).show();
                        }
                    }) {
                        @Override
                        protected Map<String, String> getParams() {
                            Map<String, String> params = new HashMap<String, String>();
                            params.put("quantity", quantity);
                            params.put("lid", sh.getString("lid", ""));
                            params.put("pid", getIntent().getStringExtra("p_id"));

                            return params;
                        }
                    };
                    queue.add(stringRequest);


                }
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent ii=new Intent(getApplicationContext(),View_shop.class);
                startActivity(ii);
            }
        });


        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                quantity=e1.getText().toString();

                int qty = Integer.parseInt(quantity);

                int tot = qty * amt;

//                Toast.makeText(Product_details.this, ""+tot, Toast.LENGTH_SHORT).show();

                Intent i = new Intent(getApplicationContext(),PaymentActivity1.class);
                i.putExtra("p",String.valueOf(tot));

                startActivity(i);

            }
        });


        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String qnty = e1.getText().toString();
                if (qnty.equalsIgnoreCase("")) {
                    e1.setError("Enter your Quantity");

                } else {

                    RequestQueue queue = Volley.newRequestQueue(Product_details.this);
                    url = "http://" + sh.getString("ip", "") + ":5000/Add_to_cart";

                    // Request a string response from the provided URL.
                    StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            // Display the response string.
                            Log.d("+++++++++++++++++", response);
                            try {
//                                Toast.makeText(Product_details.this, response + "", Toast.LENGTH_SHORT).show();
                                JSONObject json = new JSONObject(response);
                                String res = json.getString("task");

                                if (res.equalsIgnoreCase("valid")) {
//                                String lid = json.getString("id");
//                                SharedPreferences.Editor edp = sh.edit();
//                                edp.putString("lid", lid);
//                                edp.commit();
                                    Intent ik = new Intent(getApplicationContext(), userhome.class);
                                    startActivity(ik);
                                    Toast.makeText(Product_details.this, "success ", Toast.LENGTH_SHORT).show();


                                } else {

                                    Toast.makeText(Product_details.this, "Invalid", Toast.LENGTH_SHORT).show();

                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }


                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {


                            Toast.makeText(getApplicationContext(), "Error" + error, Toast.LENGTH_LONG).show();
                        }
                    }) {
                        @Override
                        protected Map<String, String> getParams() {
                            Map<String, String> params = new HashMap<String, String>();
                            params.put("qnty", qnty);
                            params.put("lid", sh.getString("lid", ""));
                            params.put("pid", getIntent().getStringExtra("p_id"));
                            params.put("ofid", getIntent().getStringExtra("offer_id"));


                            return params;
                        }
                    };
                    queue.add(stringRequest);


                }
            }
        });



    }
}