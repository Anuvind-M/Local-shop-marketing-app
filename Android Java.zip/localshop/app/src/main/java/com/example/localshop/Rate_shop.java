package com.example.localshop;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Rate_shop extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    Spinner s1;
    RatingBar r1;
    String rating,url;
    Button b1;
    SharedPreferences sh;
    ArrayList<String>shid,shop;
    String shop_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rate_shop);
        s1=findViewById(R.id.spinner);
        r1=findViewById(R.id.ratingBar2);
        b1=findViewById(R.id.button4);
        sh= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        url = "http://" + sh.getString("ip", "") + ":5000/viewshops";
        RequestQueue queue = Volley.newRequestQueue(Rate_shop.this);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                // Display the response string.
                Log.d("+++++++++++++++++", response);
                try {

//                    Toast.makeText(View_product.this, ""+response, Toast.LENGTH_SHORT).show();

                    JSONArray ar = new JSONArray(response);

                    shid = new ArrayList<>();
                    shop = new ArrayList<>();
//                    pid  = new ArrayList<>();
//                    price  = new ArrayList<>();
//                    category  = new ArrayList<>();
//                    details  = new ArrayList<>();

                    for (int i = 0; i < ar.length(); i++) {
                        JSONObject jo = ar.getJSONObject(i);
                        shid.add(jo.getString("login_id"));
                        shop.add(jo.getString("name"));
//                        pid.add(jo.getString("p_id"));
//                        price.add(jo.getString("price"));
//                        category.add(jo.getString("category"));
//                        details.add(jo.getString("details"));


                    }

                     ArrayAdapter<String> ad=new ArrayAdapter<>(Rate_shop.this,android.R.layout.simple_spinner_dropdown_item,shop);
                    s1.setAdapter(ad);

//                    l1.setAdapter(new custom2(View_product.this,product, image));
                    s1.setOnItemSelectedListener(Rate_shop.this);

                } catch (Exception e) {
                    Log.d("=========", e.toString());
                }


            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(Rate_shop.this, "err" + error, Toast.LENGTH_SHORT).show();
            }
        }) {
            @NonNull
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
//                params.put("lid", getIntent().getStringExtra("slid"));
                return params;
            }
        };
        queue.add(stringRequest);


        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rating = String.valueOf(r1.getRating());
                if (rating.equalsIgnoreCase("0.0")) {
                    Toast.makeText(Rate_shop.this, "Enter your rating ", Toast.LENGTH_SHORT).show();

                } else {

                    RequestQueue queue = Volley.newRequestQueue(Rate_shop.this);
                    url = "http://" + sh.getString("ip", "") + ":5000/rateshops";

                    // Request a string response from the provided URL.
                    StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            // Display the response string.
                            Log.d("+++++++++++++++++", response);
                            try {
                                JSONObject json = new JSONObject(response);
                                String res = json.getString("task");

                                if (res.equalsIgnoreCase("success")) {
//                                String lid = json.getString("id");
//                                SharedPreferences.Editor edp = sh.edit();
//                                edp.putString("lid", lid);
//                                edp.commit();
                                    Intent ik = new Intent(getApplicationContext(), userhome.class);
                                    startActivity(ik);
                                    Toast.makeText(Rate_shop.this, "success ", Toast.LENGTH_SHORT).show();


                                } else {

                                    Toast.makeText(Rate_shop.this, "Invalid", Toast.LENGTH_SHORT).show();

                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }


                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {


                            Toast.makeText(getApplicationContext(), "Error" + error, Toast.LENGTH_LONG).show();
                        }
                    }) {
                        @Override
                        protected Map<String, String> getParams() {
                            Map<String, String> params = new HashMap<String, String>();
                            params.put("rating", rating);
                            params.put("shopid", shop_id);
                            params.put("lid", sh.getString("lid", ""));


                            return params;
                        }
                    };
                    queue.add(stringRequest);
                }
            }
        });

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        shop_id=shid.get(position);

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}